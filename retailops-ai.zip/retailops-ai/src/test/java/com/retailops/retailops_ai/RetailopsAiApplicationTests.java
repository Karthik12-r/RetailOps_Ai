package com.retailops.retailops_ai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailopsAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
